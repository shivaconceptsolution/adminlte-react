export default function A()
{
    return(<div>
        <p>A Component</p>
    </div>)
}